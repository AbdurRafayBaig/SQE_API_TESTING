package com.api.testing;

import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

/**
 * Tests for DummyJSON Product APIs. Covers: GET, POST, PUT, DELETE.
 */
public class DummyJsonProductTests extends DummyJsonBaseApiTest {

	private static final String PRODUCTS_ENDPOINT = "/products";

	// ---------- GET /products/1 ----------
	@Test
	void getProductById_shouldReturn200AndCorrectId() {
		given().when().get(PRODUCTS_ENDPOINT + "/1").then().statusCode(200).body("id", equalTo(1)).body("title",
				notNullValue());
	}

	// ---------- POST /products/add ----------
	@Test
	void createProduct_withValidData_shouldReturn201AndNewId() {
		String requestBody = "{\n" + "  \"title\": \"SQE Test Product\",\n" + "  \"price\": 999,\n"
				+ "  \"stock\": 10\n" + "}";

		given().contentType(ContentType.JSON).body(requestBody).when().post(PRODUCTS_ENDPOINT + "/add").then()
				.statusCode(201) // DummyJSON returns 201 for created product
				.body("id", notNullValue()).body("title", equalTo("SQE Test Product"));
	}

	// ---------- PUT /products/1 ----------
	@Test
	void updateProductTitle_shouldReturn200AndUpdatedTitle() {
		String requestBody = "{\n" + "  \"title\": \"Updated SQE Product\"\n" + "}";
		given().contentType(ContentType.JSON).body(requestBody).when().put(PRODUCTS_ENDPOINT + "/1").then()
				.statusCode(200).body("id", equalTo(1)).body("title", equalTo("Updated SQE Product"));
	}

	// ---------- DELETE /products/1 ----------
	@Test
	void deleteProduct_shouldReturn200AndDeletedId() {
		given().when().delete(PRODUCTS_ENDPOINT + "/1").then().statusCode(200).body("id", equalTo(1));
	}
}
