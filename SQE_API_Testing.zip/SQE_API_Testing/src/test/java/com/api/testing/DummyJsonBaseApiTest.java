package com.api.testing;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;

/**
 * Base class for all DummyJSON API tests. Sets the base URI once for the whole
 * test class.
 */
public class DummyJsonBaseApiTest {

	@BeforeAll
	static void setup() {
		RestAssured.baseURI = "https://dummyjson.com";
	}
}
