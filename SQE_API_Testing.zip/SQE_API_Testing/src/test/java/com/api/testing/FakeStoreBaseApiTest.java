package com.api.testing;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;

/**
 * Base class for FakeStore API tests.
 */
public class FakeStoreBaseApiTest {

	@BeforeAll
	static void setup() {
		RestAssured.baseURI = "https://fakestoreapi.com";
	}
}
