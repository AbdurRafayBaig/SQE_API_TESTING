package com.api.testing;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;

public class JsonPlaceholderBaseApiTest {

    @BeforeAll
    static void setup() {
        // Base URL for JSONPlaceholder
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
    }
}
