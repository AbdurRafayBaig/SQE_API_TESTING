package com.api.testing;

import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

/**
 * Tests for JSONPlaceholder Post APIs. Covers: GET, POST, PUT, DELETE.
 */
public class JsonPlaceholderPostTests extends JsonPlaceholderBaseApiTest {

	private static final String POSTS_ENDPOINT = "/posts";

	// ---------- GET /posts/1 ----------
	@Test
	void getPostById_shouldReturn200AndCorrectId() {
		given().when().get(POSTS_ENDPOINT + "/1").then().statusCode(200).body("id", equalTo(1));
	}

	// ---------- POST /posts ----------
	@Test
	void createPost_withValidData_shouldReturn201AndNewId() {
		String requestBody = "{\n" + "  \"title\": \"SQE Test Post\",\n"
				+ "  \"body\": \"This is a test post from SQE student\",\n" + "  \"userId\": 1\n" + "}";

		given().contentType(ContentType.JSON).body(requestBody).when().post(POSTS_ENDPOINT).then().statusCode(201) // JSONPlaceholder
																													// returns
																													// 201
																													// for
																													// created
																													// resource
				.body("title", equalTo("SQE Test Post")).body("id", notNullValue());
	}

	// ---------- PUT /posts/1 ----------
	@Test
	void updatePost_shouldReturn200AndUpdatedTitle() {
		String requestBody = "{\n" + "  \"id\": 1,\n" + "  \"title\": \"Updated SQE Post\",\n"
				+ "  \"body\": \"Updated body content\",\n" + "  \"userId\": 1\n" + "}";

		given().contentType(ContentType.JSON).body(requestBody).when().put(POSTS_ENDPOINT + "/1").then().statusCode(200)
				.body("title", equalTo("Updated SQE Post"));
	}

	// ---------- DELETE /posts/1 ----------
	@Test
	void deletePost_shouldReturn200() {
		given().when().delete(POSTS_ENDPOINT + "/1").then().statusCode(200);
	}
}
