package com.api.testing;

import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

/**
 * Tests for FakeStore Product APIs. Covers: GET, POST, PUT, DELETE.
 */
public class FakeStoreProductTests extends FakeStoreBaseApiTest {

	private static final String PRODUCTS_ENDPOINT = "/products";

	// ---------- GET /products/1 ----------
	@Test
	void getProductById_shouldReturn200AndCorrectId() {
		given().when().get(PRODUCTS_ENDPOINT + "/1").then().statusCode(200).body("id", equalTo(1));
	}

	// ---------- POST /products ----------
	@Test
	void createProduct_withValidData_shouldReturn201AndNewId() {
		String requestBody = "{\n" + "  \"title\": \"SQE Test Product\",\n" + "  \"price\": 99.99,\n"
				+ "  \"description\": \"Test product from SQE student\",\n"
				+ "  \"image\": \"https://i.pravatar.cc\",\n" + "  \"category\": \"electronics\"\n" + "}";

		given().contentType(ContentType.JSON).body(requestBody).when().post(PRODUCTS_ENDPOINT).then().statusCode(201) // adjust
																														// if
																														// API
																														// returns
																														// 200
																														// instead
				.body("title", equalTo("SQE Test Product")).body("id", notNullValue());
	}

	// ---------- PUT /products/1 ----------
	@Test
	void updateProduct_shouldReturn200AndUpdatedTitle() {
		String requestBody = "{\n" + "  \"title\": \"Updated SQE Product\",\n" + "  \"price\": 149.99,\n"
				+ "  \"description\": \"Updated description\",\n" + "  \"image\": \"https://i.pravatar.cc\",\n"
				+ "  \"category\": \"electronics\"\n" + "}";

		given().contentType(ContentType.JSON).body(requestBody).when().put(PRODUCTS_ENDPOINT + "/1").then()
				.statusCode(200).body("title", equalTo("Updated SQE Product"));
	}

	// ---------- DELETE /products/1 ----------
	@Test
	void deleteProduct_shouldReturn200() {
		given().when().delete(PRODUCTS_ENDPOINT + "/1").then().statusCode(200);
	}
}
